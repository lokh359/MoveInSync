function adduser(){
	document.getElementById("table").style.display="block";
}

var m1 = [];
	var m2 = [];
	var m3 = [];
	var m4 = [];
	var m5 =[];

	var n = 1;
	var x = 0;
	var i=1;

	function Row(){

		var AddRow = document.getElementById('table1');
		var NewRow = AddRow.insertRow(n);

		m1[x] = document.getElementById("name").value;
		m2[x] =i;
		a= document.getElementById("city");
		m3[x]=a.options[a.selectedIndex].value;
		

		m4[x] = document.getElementById("degree").value;
		var date=new Date(Date.now());
		
		m5[x]=date;
		
		
		

		var cell1 = NewRow.insertCell(0);
		var cell2 = NewRow.insertCell(1);
		var cell3 = NewRow.insertCell(2);
		var cell4 = NewRow.insertCell(3);
		var cell5 = NewRow.insertCell(4);

		cell1.innerHTML = m1[x];
		cell2.innerHTML = m2[x];
		cell3.innerHTML = m3[x];
		cell4.innerHTML = m4[x];
		cell5.innerHTML=m5[x];

		n++;
		x++;
		i++;
	}
